/******************************************************************************
 * Project:  wxGIS (GIS Catalog)
 * Purpose:  wxGISConfig class.
 * Author:   Bishop (aka Barishnikov Dmitriy), polimax@mail.ru
 ******************************************************************************
*   Copyright (C) 2009  Bishop
*
*    This program is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
*    (at your option) any later version.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*    GNU General Public License for more details.
*
*    You should have received a copy of the GNU General Public License
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ****************************************************************************/
#include "wxgis/framework/config.h"

wxGISConfig::wxGISConfig(void)
{
 	wxStandardPaths stp;

	m_sUserConfigDir = stp.GetUserConfigDir() + wxFileName::GetPathSeparator() + CONFIG_DIR;
	m_sExeDirPath = wxPathOnly(stp.GetExecutablePath());
	
	if(!wxDirExists(m_sUserConfigDir))
		wxFileName::Mkdir(m_sUserConfigDir, 0777, wxPATH_MKDIR_FULL);
}

wxGISConfig::~wxGISConfig(void)
{
	Clean();
}

void wxGISConfig::Clean(void)
{
	for(size_t i = 0; i < m_configs_arr.size(); i++)
	{
		m_configs_arr[i].pXmlDoc->Save(m_configs_arr[i].xml_path);
		wxDELETE(m_configs_arr[i].pXmlDoc);
	}
	m_configs_arr.empty();
}

wxString wxGISConfig::GetLocale(wxString sApp)
{
	return GetNodeValue(sApp, wxT("Loc"), wxT("locale"), wxT("en"));
}

wxString wxGISConfig::GetLogDir(wxString sApp)
{
	wxString default_path = m_sUserConfigDir + wxFileName::GetPathSeparator() + sApp +  wxFileName::GetPathSeparator() + wxT("log");
	return GetNodeValue(sApp, wxT("Log"), wxT("path"), default_path);
}

wxString wxGISConfig::GetSysDir(wxString sApp)
{
	wxString default_path = m_sExeDirPath + wxFileName::GetPathSeparator() + wxT("sys");
	return GetNodeValue(sApp, wxT("Sys"), wxT("path"), default_path);
}

wxXmlNode* wxGISConfig::GetXmlConfig(wxString sApp)
{
	wxXmlNode* pReturnData(NULL);
	if(sApp.IsEmpty())
		sApp = wxString(wxT("alone"));
	//lookup for preloaded config
	for(size_t i = 0; i < m_configs_arr.size(); i++)
		if(m_configs_arr[i].sApp == sApp)
			return m_configs_arr[i].pXmlRoot;

	//lookup for config
	wxString sAdd;
	if(sApp != wxString(wxT("alone")))
		sAdd = wxFileName::GetPathSeparator() + sApp;
	wxString user_dir = m_sUserConfigDir + sAdd;
	wxString user_path = user_dir + wxFileName::GetPathSeparator() + CONFIG_NAME;

	if(!wxDirExists(user_dir))
		wxFileName::Mkdir(user_dir, 0777, wxPATH_MKDIR_FULL);

	wxXmlDocument* pDataUser(NULL);
	wxXmlNode* pRetRootUser(NULL);

	if(wxFileName::FileExists(user_path))
	{
		pDataUser = new wxXmlDocument(user_path);
		pRetRootUser = pDataUser->GetRoot();
		WXXMLCONF conf = {sApp, pDataUser, pRetRootUser, user_path};
		m_configs_arr.push_back(conf);

		return pRetRootUser;
	}

	//copy from origin config
	wxString origin_path = m_sExeDirPath + wxFileName::GetPathSeparator() + wxT("config") + wxFileName::GetPathSeparator() + sApp + wxT(".xml");
	if(wxFileName::FileExists(origin_path))
	{
		pDataUser = new wxXmlDocument(origin_path);
		pRetRootUser = pDataUser->GetRoot();
		WXXMLCONF conf = {sApp, pDataUser, pRetRootUser, user_path};
		m_configs_arr.push_back(conf);

		return pRetRootUser;
	}
	return NULL;
}

wxString wxGISConfig::GetLocaleDir(wxString sApp)
{
	wxString default_path = m_sExeDirPath + wxFileName::GetPathSeparator() + wxT("locale");
	return GetNodeValue(sApp, wxT("Loc"), wxT("path"), default_path);
}

wxString wxGISConfig::GetNodeValue(wxString sApp, wxString sNodeName, wxString sParamName, wxString sDefParamVal)
{
	wxXmlNode* pRootUser = GetXmlConfig(sApp);
	if(pRootUser == NULL)
		return sDefParamVal;

	wxString UserVal(NON);
	//check def value in user config
	if(pRootUser->GetName() == sApp)
	{
		wxXmlNode* pChild = pRootUser->GetChildren();
		while(pChild)
		{
			if(pChild->GetName() == sNodeName)
			{
				UserVal = pChild->GetPropVal(sParamName, DEF);
				if(UserVal == DEF)
					pChild->AddProperty(sParamName, sDefParamVal);
				break;
			}
			pChild = pChild->GetNext();
		}
	}

	if(UserVal == NON)
	{
		wxXmlNode* pLoc2 = new wxXmlNode(pRootUser, wxXML_ELEMENT_NODE, sNodeName);
		pLoc2->AddProperty(sParamName, sDefParamVal);
		UserVal = sDefParamVal;
	}
	return UserVal;
}

wxXmlNode* wxGISConfig::GetNodeByName(wxXmlNode* pRoot, wxString sName)
{
	wxXmlNode* pChildren = pRoot->GetChildren();
	while(pChildren)
	{
		if(pChildren->GetName() == sName)
			return pChildren;
		pChildren = pChildren->GetNext();
	}
	return NULL;
}
wxXmlNode* wxGISConfig::GetRootNodeByName(wxString sApp, wxString sName)
{
	wxXmlNode* pRoot = GetXmlConfig(sApp);
	return GetNodeByName(pRoot, sName);
}

//wxXmlNode* wxGISConfig::GetGlobalXmlConfig(bool bIsOrigin)
//{
//	wxXmlNode* pRetData(NULL);
//	if(bIsOrigin)
//	{
//		for(size_t i = 0; i < m_configs_arr.size(); i++)
//			if(m_configs_arr[i].sApp == wxT("ORIGIN"))
//				return m_configs_arr[i].pXmlRoot;
//	}
//	else
//	{
//		for(size_t i = 0; i < m_configs_arr.size(); i++)
//			if(m_configs_arr[i].sApp == CONFIG_DIR)
//				return m_configs_arr[i].pXmlRoot;
//	}
//	//try to load
//	wxString global_path = m_sExeDirPath + wxFileName::GetPathSeparator() + wxT("config") + wxFileName::GetPathSeparator() + CONFIG_NAME;
//	wxString common_path = m_sConfigDir + wxFileName::GetPathSeparator() + CONFIG_NAME;
//
//	if(!wxDirExists(m_sConfigDir))
//		wxFileName::Mkdir(m_sConfigDir, 0777, wxPATH_MKDIR_FULL);
//
//	wxXmlDocument* pDataGlobal(NULL);
//	wxXmlNode* pRetRootGlobal(NULL);
//	if(!wxFileName::FileExists(global_path))
//		return NULL;
//
//	pDataGlobal = new wxXmlDocument(global_path);
//	pRetRootGlobal = pDataGlobal->GetRoot();
//
//	WXXMLCONF conf = {false, wxT("ORIGIN"), pDataGlobal, pRetRootGlobal, wxString()};
//	m_configs_arr.push_back(conf);
//
//	wxXmlDocument* pDataCommon(NULL);
//	wxXmlNode* pRetRootCommon(NULL);
//	if(wxFileName::FileExists(common_path))
//	{
//		pDataCommon = new wxXmlDocument(common_path);
//		pRetRootCommon = pDataCommon->GetRoot();
//	}
//	else
//	{
//		pDataCommon = new wxXmlDocument();
//		pRetRootCommon = new wxXmlNode(wxXML_ELEMENT_NODE, CONFIG_DIR);
//		pDataCommon->SetRoot(pRetRootCommon);
//	}
//	WXXMLCONF conf1 = {false, CONFIG_DIR, pDataCommon, pRetRootCommon, common_path};
//	m_configs_arr.push_back(conf1);
//
//	if(bIsOrigin)
//		return pRetRootGlobal;
//	else
//		return pRetRootCommon;
//}
//loading config
	////m_sUserConfigName = wxFileName( m_sUserDataDir, XML_CONFIG );
	////wxFileName sConfigAltName = wxFileName( wxPathOnly(GetExecutablePath()) + wxFileName::GetPathSeparator() +
	////	wxString(wxT("config")), XML_CONFIG );
	////if(wxFileName::IsFileReadable(m_sConfigName.GetFullPath()))
	////{
	////	//doc = new wxXmlDocument(confname.GetFullPath());
	////	//if(doc != NULL && doc->IsOk()/*doc.Load(confname.GetFullPath())*/)
	////	//{
	////	//	wxXmlNode* pRootNode = doc->GetRoot();
	////	//	if (pRootNode->GetName() == XML_ROOT_NAME)
	////	//		Serialize(pRootNode, false);
	////	//	else
	////	//	{
	////	//		wxLogError(_("weMonClient: Config format not supported! Config file: %s"), confname.GetFullPath().c_str());
	////	//		return false;
	////	//	}
	////	//}
	////}
	////else if(wxFileName::IsFileReadable(sConfigAltName.GetFullPath()))
	////{
	////	//doc = new wxXmlDocument(confname_alt.GetFullPath());
	////	//if(doc != NULL && doc->IsOk()/*doc.Load(confname.GetFullPath())*/)
	////	////if(doc.Load(confname_alt.GetFullPath()))
	////	//{
	////	//	wxXmlNode* pRootNode = doc->GetRoot();
	////	//	if (pRootNode->GetName() == XML_ROOT_NAME)
	////	//		Serialize(pRootNode, false);
	////	//	else
	////	//	{
	////	//		wxLogError(_("weMonClient: Config format not supported! Config file: %s"), confname_alt.GetFullPath().c_str());
	////	//		return false;
	////	//	}
	////	//}	
	////}
	////else
	////{
	////	wxLogError(_("wxGISCatalogApp: Config is absent! Config file lookup path: %s; %s"), m_sConfigName.GetFullPath().c_str()
	////		sConfigAltName.GetFullPath().c_str());
	////	return false;
	////}
	//setup loging
	//if(m_sLogDirPath.IsEmpty())
	//{
	//	m_sLogDirPath = sUserConfigDir + wxFileName::GetPathSeparator() + wxString(wxT("Log"));
	//	if(!wxDirExists(m_sLogDirPath))
	//		wxFileName::Mkdir(m_sLogDirPath);
	//}
	////if(m_sSysDirPath.IsEmpty())
	////{
	////	m_sSysDirPath = wxPathOnly(GetExecutablePath()) + wxFileName::GetPathSeparator() + wxString(wxT("Sys"));
	////	if(!wxDirExists(m_sSysDirPath))
	////	{
	////		wxLogError(_("wxGISCatalogApp: System dir is absent!"));
	////		return false;
	////	}
	////}